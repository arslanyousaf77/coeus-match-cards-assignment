class Player
    def get_my_available_pieces(board)
        
    end
    
end